<html>
<body >
<?php
$dbh=mysqli_connect('localhost','root','') or die(mysqli_error());
mysqli_select_db($dbh,'project1') or die (mysqli_error($dbh));

$examid=$_REQUEST['examid'];



$query="delete from examresult1 where examid='$examid'";
$result=mysqli_query($dbh,$query) or die(mysqli_error($dbh));
echo "data deleted successfully!!!!";

$var=mysqli_query($dbh,"SELECT * from examresult1");
echo"<table border size=1>";
echo"<tr><th>examid</th> <th>examresult</th> <th>marks</th><th>password</th><th>sname</th><th>subid</th> </tr>";
while ($arr=mysqli_fetch_row($var))
{
	echo"<tr> <td>$arr[0]</td> <td>$arr[1]</td> <td>$arr[2]</td><td>$arr[3]</td><td>$arr[4]</td><td>$arr[5]</td> </tr>";
}
echo"</table>";

?>

<h4><font color="cyan"><a href="eresultdel.html">click here to delete the examresult details</a></font></h4>
<h4><font color="cyan"><a href="index.html">click here to go back to the home page </a></font></h4>
</body>
</html>