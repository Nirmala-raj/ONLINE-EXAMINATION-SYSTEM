<html>
<body bgcolor='voilet'>
<?php
$dbh=mysqli_connect('localhost','root','') or die(mysqli_error());
mysqli_select_db($dbh,'project')or die(mysqli_error($dbh));
$patientid=$_REQUEST['patientid'];
$patientname=$_REQUEST['patientname'];
$patientaddress=$_REQUEST['patientaddress'];
$gender=$_REQUEST['gender'];
$phno=$_REQUEST['phno'];
$query="INSERT INTO patient VALUES('$patientid','$patientname','$patientaddress','$gender','$phno')";
$result=mysqli_query($dbh,$query)or die(mysqli_error($dbh));
echo "Data Inserted sucesfull!!!";
$var=mysqli_query($dbh,"select * from patient");
echo"<table border size=1>";
echo"<tr><th>patientid</th><th>patientname</th><th>patientaddress</th><th>gender</th><th>phno</th></tr>";
while($arr=mysqli_fetch_row($var))
{
echo"<tr><td>$arr[0]</td><td>$arr[1]</td><td>$arr[2]</td><td>$arr[3]</td><td>$arr[4]</td></tr>";
}
echo"</table>";
?>
<h3><font color='red'><a href="app.html">click here to appointment details</a></font></h3>
</body>
</html>  