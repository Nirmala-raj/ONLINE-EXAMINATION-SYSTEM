<html>
<body bgcolor='yellow'>
<?php
$dbh=mysqli_connect('localhost','root','') or die(mysqli_error());
mysqli_select_db($dbh,'project')or die(mysqli_error($dbh));
$adminame=$_REQUEST['adminame'];
$password=$_REQUEST['password'];
$query="INSERT INTO admin VALUES('$adminame','$password')";
$result=mysqli_query($dbh,$query)or die(mysqli_error($dbh));
echo "Data inserted sucesfull!!!";
$var=mysqli_query($dbh,"select * from admin");
echo"<table border size=1>";
echo"<tr><th>adminame</th><th>password</th></tr>";
while($arr=mysqli_fetch_row($var))
{
echo"<tr><td>$arr[0]</td><td>$arr[1]</td></tr>";
}
echo"</table>";
?>
<h3><font color='red'><a href="doc.html">click here to doctors details</a></font></h3>
</body>
</html>  