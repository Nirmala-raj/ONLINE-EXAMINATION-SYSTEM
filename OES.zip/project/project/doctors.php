<html>
<body bgcolor='silver'>
<?php
$dbh=mysqli_connect('localhost','root','')or die(mysqli_error());
mysqli_select_db($dbh,'project')or die(mysqli_error($dbh));
$doctorid=$_REQUEST['doctorid'];
$doctorname=$_REQUEST['doctorname'];
$specialization=$_REQUEST['specialization'];
$phno=$_REQUEST['phno'];
$query="INSERT INTO doctors VALUES('$doctorid','$doctorname','$specialization','$phno')";
$result=mysqli_query($dbh,$query)or die(mysqli_error($dbh));
echo "Data Inserted Successfully!!!";
$var=mysqli_query($dbh,"select * from doctors");
echo"<table border size=1>";
echo"<tr><th>doctorid</th><th>doctorname</th><th>specialization</th><th>phno</th></tr>";
while($arr=mysqli_fetch_row($var))
{
echo"<tr><td>$arr[0]</td><td>$arr[1]</td><td>$arr[2]</td><td>$arr[3]</td></tr>";
}
echo"</table>";
?>
<h3><font color='green'><a href="pat.html">click here to patient details</a></font></h3>
</body>
</html>  