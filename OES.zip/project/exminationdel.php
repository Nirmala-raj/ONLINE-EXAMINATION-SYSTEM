<html>
<body >
<?php
$dbh=mysqli_connect('localhost','root','') or die(mysqli_error());
mysqli_select_db($dbh,'project1') or die (mysqli_error($dbh));

$subid=$_REQUEST['subid'];



$query="delete from examination1 where subid='$subid'";
$result=mysqli_query($dbh,$query) or die(mysqli_error($dbh));
echo "data deleted successfully!!!!";

$var=mysqli_query($dbh,"SELECT * from examination1");
echo"<table border size=1>";
echo"<tr><th>subid</th> <th>sname</th> <th>branch</th><th>sem</th><th>examloc</th><th>regnum</th> </tr>";
while ($arr=mysqli_fetch_row($var))
{
	echo"<tr> <td>$arr[0]</td> <td>$arr[1]</td> <td>$arr[2]</td><td>$arr[3]</td><td>$arr[4]</td><td>$arr[5]</td> </tr>";
}
echo"</table>";

?>

<h4><font color="cyan"><a href="exminationdel.html">click here to delete the registration details</a></font></h4>
<h4><font color="cyan"><a href="index.html">click here to go back to the home page </a></font></h4>
<h4><font color="cyan"><a href="eresult.html">click here to go examresult page </a></font></h4>
</body>
</html>