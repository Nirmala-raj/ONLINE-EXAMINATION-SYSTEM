<html>
<body bgcolor='voilet'>
<?php
$dbh=mysqli_connect('localhost','root','') or die(mysqli_error());
mysqli_select_db($dbh,'project1')or die(mysqli_error($dbh));
$subid=$_REQUEST['subid'];
$subname=$_REQUEST['subname'];
$branch=$_REQUEST['branch'];
$sem=$_REQUEST['sem'];
$examloc=$_REQUEST['examloc'];
$regnum=$_REQUEST['regnum'];
$query="INSERT INTO examination1 VALUES('$subid','$subname','$branch','$sem','$examloc','$regnum')";
$result=mysqli_query($dbh,$query)or die(mysqli_error($dbh));
echo "Data Inserted sucesfull!!!";
$var=mysqli_query($dbh,"select * from examination1");
echo"<table border size=1>";
echo"<tr><th>subid</th><th>subname</th><th>branch</th><th>sem</th><th>examloc</th><th>regnum</th></tr>";
while($arr=mysqli_fetch_row($var))
{
echo"<tr><td>$arr[0]</td><td>$arr[1]</td><td>$arr[2]</td><td>$arr[3]</td><td>$arr[4]</td><td>$arr[5]</td></tr>";
}
echo"</table>";
?>
<h4><font color="cyan"><a href="exminationdel.html">click here to delete the examination details</a></font></h4>
<h4><font color="cyan"><a href="index.html">click here to go back to the home page </a></font></h4>
<h3><font color='red'><a href="eresult.html">click here to examresult</a></font></h3>
</body>
</html>  