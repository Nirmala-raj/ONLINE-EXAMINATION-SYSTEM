<html>
<body bgcolor='skyblue'>
<?php
$dbh=mysqli_connect('localhost','root','') or die(mysqli_error());
mysqli_select_db($dbh,'project1')or di(mysqli_error($dbh));
$examid=$_REQUEST['examid'];
$examresult=$_REQUEST['examresult'];
$marks=$_REQUEST['marks'];
$password=$_REQUEST['password'];
$sname=$_REQUEST['sname'];
$subid=$_REQUEST['subid'];
$query="INSERT INTO examresult1 VALUES('$examid','$examresult','$marks','$password','$sname','$subid')";
$result=mysqli_query($dbh,$query)or die(mysqli_error($dbh));
echo "Data inserted sucesfull!!!";
$var=mysqli_query($dbh,"select * from examresult1");
echo"<table border size=1>";
echo"<tr><th>examid</th><th>examresult</th><th>marks</th><th>password</th><th>sname</th><th>subid</th></tr>";
while($arr=mysqli_fetch_row($var))
{
echo"<tr><td>$arr[0]</td><td>$arr[1]</td><td>$arr[2]</td><td>$arr[3]</td><td>$arr[4]</td><td>$arr[5]</td></tr>";
}
echo"</table>";
?>
<h4><font color="cyan"><a href="eresultdel.html">click here to delete the examresult details</a></font></h4>
<h4><font color="cyan"><a href="index.html">click here to go back to the home page </a></font></h4>
</body>
</html>  